<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Beranda extends Model
{
    protected $fillable = [
        'imageBanner',
        'imageSection2',
        'imageSection3'
    ];
}
