<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visi extends Model
{
    protected $fillable = [
        'visi',
        'imageVisi',
        'misi',
        'imageMisi'
    ];
}
