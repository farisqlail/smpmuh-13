<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeskEkstra extends Model
{
    protected $fillable = [
        'image',
        'deskripsi'
    ];
}
