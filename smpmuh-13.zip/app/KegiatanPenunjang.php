<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KegiatanPenunjang extends Model
{
    protected $fillable = [
        'nama_kegiatan'
    ];
}
